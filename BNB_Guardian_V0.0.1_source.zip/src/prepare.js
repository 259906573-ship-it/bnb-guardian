import { Contract, Interface, getAddress, keccak256, toUtf8Bytes, toQuantity } from 'ethers';
import { assertTestnet,atBlock,position,network,comptrollerAbi,vTokenAbi,registryAbi,fuguRegistryAbi,erc20Abi,lower,json } from './chain.js';
import { chooseRepayment } from './risk.js';
function envelope(kind, from, to, data, value, block) {
 const plan={version:'V0.0.1',kind,chainId:97,from:getAddress(from),to:getAddress(to),data,value:toQuantity(value),observedBlock:block.number,observedBlockHash:block.hash,expiresAt:Math.floor(Date.now()/1000)+120,requiresUserConfirmation:true,broadcast:false};
 return {...plan,planHash:keccak256(toUtf8Bytes(json(plan)))};
}
export async function prepareRegister(p,wallet,baseUrl) {
 await assertTestnet(p); const u=new URL(baseUrl);
 if(u.protocol!=='https:'||u.username||u.password||u.hostname==='localhost'||/^127\./.test(u.hostname))throw new Error('PUBLIC_HTTPS_REQUIRED');
 const uri=new URL('/agent-registration.json',u).href;
 return envelope('erc8004-register',wallet,network.identityRegistry,new Interface(registryAbi).encodeFunctionData('register(string)',[uri]),0n,await atBlock(p));
}
export async function prepareListing(p,wallet,agentWallet,id,baseUrl,priceUsd8,periodSeconds) {
 await assertTestnet(p);
 const identity=new Contract(network.identityRegistry,registryAbi,p);
 if(lower(await identity.ownerOf(id))!==lower(wallet))throw new Error('NOT_REGISTERED_OWNER');
 const market=new Contract(network.helloFugu.registry,fuguRegistryAbi,p);
 if(lower(await market.identityRegistry())!==lower(network.identityRegistry))throw new Error('MARKET_REGISTRY_MISMATCH');
 if(await market.listingByAgentId(id)!==0n)throw new Error('ALREADY_LISTED');
 const u=new URL(baseUrl);if(u.protocol!=='https:')throw new Error('PUBLIC_HTTPS_REQUIRED');
 if(BigInt(priceUsd8)<=0n||!Number.isSafeInteger(periodSeconds)||periodSeconds<60)throw new Error('INVALID_LISTING_TERMS');
 return envelope('hello-fugu-list',wallet,network.helloFugu.registry,new Interface(fuguRegistryAbi).encodeFunctionData('list',[id,getAddress(agentWallet),3,priceUsd8,periodSeconds,new URL('/agent-registration.json',u).href]),0n,await atBlock(p));
}
export async function prepareRepay(p,{borrower,payer,market,capRaw,thresholds}) {
 borrower=getAddress(borrower);payer=getAddress(payer);market=getAddress(market);
 const block=await atBlock(p);const s=await position(p,borrower,block.number);
 const chosen=chooseRepayment(s,market,capRaw,thresholds);
 const v=new Contract(market,vTokenAbi,p);
 if(lower(await v.comptroller({blockTag:block.number}))!==lower(network.comptroller))throw new Error('COMPTROLLER_MISMATCH');
 const native=lower(market)===lower(network.markets.vBNB);
 let data,value=0n,token=null;
 if(native){
   value=chosen.amountRaw;
   if(await p.getBalance(payer,block.number)<=value)throw new Error('INSUFFICIENT_NATIVE_BALANCE');
   data=new Interface(vTokenAbi).encodeFunctionData('repayBorrowBehalf(address)',[borrower]);
 }else{
   token=getAddress(await v.underlying({blockTag:block.number}));const t=new Contract(token,erc20Abi,p);
   const [balance,allowance]=await Promise.all([t.balanceOf(payer,{blockTag:block.number}),t.allowance(payer,market,{blockTag:block.number})]);
   if(balance<chosen.amountRaw)throw new Error('INSUFFICIENT_TOKEN_BALANCE');
   if(allowance<chosen.amountRaw){
     // No unlimited approval; this is a separate user confirmation before repayment.
     return {...envelope('approve-exact-amount',payer,token,new Interface(erc20Abi).encodeFunctionData('approve',[market,chosen.amountRaw]),0n,block),spender:market,amountRaw:chosen.amountRaw,next:'Re-run prepareRepay after approval is confirmed. This approval is not a qualifying risk-management action.'};
   }
   data=new Interface(vTokenAbi).encodeFunctionData('repayBorrowBehalf(address,uint256)',[borrower,chosen.amountRaw]);
 }
 const request={from:payer,to:market,data,value:toQuantity(value)};
 const result=await p.send('eth_call',[request,toQuantity(block.number)]);
 if(!native && new Interface(vTokenAbi).decodeFunctionResult('repayBorrowBehalf(address,uint256)',result)[0]!==0n)throw new Error('REPAY_SIMULATION_ERROR');
 const gas=await p.estimateGas(request); const fee=await p.getFeeData();
 return {...envelope('venus-repay',payer,market,data,value,block),borrower,amountRaw:chosen.amountRaw,token,partial:chosen.partial,risk:chosen.risk,position:s,gas:toQuantity(gas),estimatedGasCostWei:gas*(fee.gasPrice||0n),simulation:'passed',warning:'Recheck risk, amount and chain in the wallet before signing. A successful transaction must also contain a Venus RepayBorrow event.'};
}
