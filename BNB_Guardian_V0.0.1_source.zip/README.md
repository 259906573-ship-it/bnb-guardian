# BNB Guardian V0.0.1

Venus BSC Testnet（Chain ID 97）借贷风险监控与用户确认偿债交易准备工具。参加 BNB Chain Set and Earn 的独立开发项目。**当前为开发版，不是已完成参赛资格的 Agent。**

公开仓库：https://github.com/259906573-ship-it/bnb-guardian

| 项目 | 状态 |
|---|---|
| 报名钱包/暂定操作钱包 | `0x9F81A9588c310b90A0636E8D2fb31523a57fbaDC` |
| 网络 | BSC Testnet 97；程序拒绝主网 |
| ERC-8004 Agent ID | 未注册；不得填写虚构 ID |
| Identity Registry | `0x8004A818BFB912233c491871b3d84c89A494BD9e` |
| 公共服务部署地址 | 未部署，等待用户确认 |
| 市场上架链接 | 未上架，首选 HelloFugu |
| 功能链上交易 | 0；未签名/未发送任何交易 |
| AI | 可选 Responses 接口已写入，未配置/未实测；当前规则分析 |
| 小创功能图标 | 待最高质量生图入口核实，未集成 |
| 资格 | 未达标，见核验报告 |

## 本地启动

要求 Node.js 22 或更新版本。

```sh
npm ci --ignore-scripts
npm test
npm start
```

默认监听 `127.0.0.1:8797`。不需要私钥。配置见 `.env.example`；使用环境变量或 Node `--env-file=.env`，不要把真实密钥文件提交仓库。

```sh
node --env-file=.env src/server.js
npm run probe
npm run qualify
node scripts/explain.js 0x你的公开地址
```

`qualify` 未完成时退出码为 2，不把缺失数据默认为通过。默认查询与监控钱包是用户提供的报名钱包。RPC 失败会明确返回不可用；本地健康状态不代表公共持续在线。

## 接口

- `GET /healthz`：监控/RPC 状态，失败 503。
- `GET /agent-registration.json`：ERC-8004 注册元数据。
- `GET /.well-known/agent-card.json`：同一注册元数据别名，不宣称 A2A 协议支持。
- `GET /v1/position?account=0x…`：区块固定的 Venus 快照与风险计算。
- `GET /v1/watch`：一分钟轮询的最新结果，含观测时间。
- `POST /mcp`：MCP JSON-RPC `initialize`、`tools/list`、`tools/call`；查询工具 `venus_position`。

```json
{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"venus_position","arguments":{"account":"0x9F81A9588c310b90A0636E8D2fb31523a57fbaDC"}}}
```

当前 MCP 服务负责查询，尚未接入市场订阅驱动的偿债执行。AI 解释是本地 CLI 功能，设置 `OPENAI_API_KEY` 与 `OPENAI_MODEL` 才调用模型，API 消耗需要自行确认；未配置则标记 rules-only。

## 风险管理

读取 Venus Core Comptroller、预言机与账户快照。覆盖率 = 按抵押因子加权的抵押价值 / 债务价值，与 Comptroller 净流动性进行一致性核对。无债务返回 null；低于 1.25 才建议偿还，目标 1.50。此覆盖率不是 Aave 清算阈值 HF，不承诺避免清算。

仅准备白名单 vBNB/vUSDT/vUSDC 的 `repayBorrowBehalf`，金额受用户原始单位上限限制。ERC20 授权不足时返回独立的精确额度授权草稿；必须完成授权后重新模拟。VAI 债务、其他市场、错误链和不一致快照拒绝处理。

```sh
node scripts/prepare.js repay /绝对路径/repay-input.json
node scripts/prepare.js register /绝对路径/register-input.json
node scripts/prepare.js list /绝对路径/list-input.json
```

示例输入见 `docs/操作说明.md`。输出含链、目标、calldata、金额、观测区块、有效期、planHash；**不签名、不广播**。不得把准备或仿真当成链上成功。每次签名前重新生成草稿和检查余额、风险、有效期，钱包必须显示 97。

## 证据与资格

在 `config/campaign.json` 填真实报名时间、证据链接、注册 ID 和交易记录。脚本核对：身份所有者、公共卡与 MCP 调用、市场上架、真实订阅事件、外部订阅完成、实际 Venus 偿还事件、前后债务变化、三个 UTC 日期及不同 Agent 去重。

限制：目前只实现 HelloFugu Chain 97 事件适配，因此**第二市场暂不能自动核验**。外部钱包共同或间接资金来源不能仅靠回执证明，仍须资金历史和官方审核。注册、授权、普通转账、查询均不计入五次功能操作。

## 安全与部署状态

项目不接收、不保存借款人私钥。没有自动签名器。`.gitignore` 排除环境文件、密钥和运行数据；请使用服务器秘密管理或本地权限为 600 的环境文件保存 API Key，禁止日志输出。Dockerfile 提供无 root 服务模板，真实公共部署与 HTTPS、监控/重启需要另行配置并由用户确认。

正式交付还需要：AI 实测、功能图标、确认部署、报名核对、ERC-8004 注册、上架、市场交付联动、第二市场适配、真实独立雇佣与合法风险管理交易。

官方规则、平台比较、成本和来源见 [方案与规则](docs/方案与规则.md)。
