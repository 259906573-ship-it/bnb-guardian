import {json} from './chain.js';
export async function explain(snapshot,risk) {
 if(!process.env.OPENAI_API_KEY||!process.env.OPENAI_MODEL)return {mode:'rules-only',text:risk.explanation||'No repayment is required by the deterministic rules.',aiVerified:false};
 try {
  const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},signal:AbortSignal.timeout(20000),body:JSON.stringify({model:process.env.OPENAI_MODEL,store:false,max_output_tokens:700,instructions:'Explain the supplied Venus testnet risk assessment in concise Chinese. Separate observed data from uncertainty. Never invent prices, transactions, hires or guarantees. Do not propose borrowing, withdrawing collateral or transfers. All transaction decisions are made by deterministic rules and require user approval. The health factor is collateral-factor coverage, not Aave HF.',input:json({snapshot,risk})})});
  if(!r.ok)throw new Error('AI_UNAVAILABLE');const data=await r.json();
  const text=(data.output||[]).filter(x=>x.type==='message').flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('\n');
  if(!text)throw new Error('AI_EMPTY_RESPONSE');return {mode:'openai-responses',model:process.env.OPENAI_MODEL,text,aiVerified:true,authority:'explanation-only'};
 }catch{return {mode:'rules-only',text:risk.explanation||'No repayment required.',aiVerified:false,aiError:'AI_UNAVAILABLE'};}
}
