export const VERSION='V0.0.2';
export const SEMVER='0.0.2';
