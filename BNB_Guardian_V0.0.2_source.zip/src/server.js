import http from 'node:http';
import { getAddress } from 'ethers';
import { provider,atBlock,position,json,network } from './chain.js';
import {assess} from './risk.js';
import {explain} from './ai.js';
const p=provider(), cache=new Map(), limits=new Map();
const watched=(process.env.WATCH_ADDRESSES||process.env.CAMPAIGN_WALLET||'0x9F81A9588c310b90A0636E8D2fb31523a57fbaDC').split(',').filter(Boolean).map(getAddress);
let beat={ok:false,lastSuccess:null},busy=false;
async function refresh(){if(busy)return;busy=true;try{const b=await atBlock(p);for(const a of watched){const s=await position(p,a,b.number);cache.set(a,{position:s,risk:assess(s)});}beat={ok:true,lastSuccess:Date.now(),block:b.number};}catch{beat={...beat,ok:false,error:'CHAIN_OR_MONITOR_UNAVAILABLE'};}finally{busy=false;}}
await refresh();const timer=setInterval(refresh,60000);timer.unref();
function base(){return (process.env.PUBLIC_BASE_URL||`http://127.0.0.1:${process.env.PORT||8797}`).replace(/\/$/,'');}
export function registration(){return {type:'https://eips.ethereum.org/EIPS/eip-8004#registration-v1',name:'BNB Guardian',description:'V0.0.2 Venus BSC Testnet health-factor coverage monitoring and user-confirmed debt repayment. Mainnet denied. No autonomous signing configured.',services:[{name:'MCP',endpoint:`${base()}/mcp`,version:'2025-06-18'}],active:beat.ok,x_category:'health factor',x_chainId:97,x_version:'V0.0.2',x_health:`${base()}/healthz`,x_executionMode:'user-confirmed unsigned intents',registrations:process.env.AGENT_ID?[{agentId:Number(process.env.AGENT_ID),agentRegistry:`eip155:97:${network.identityRegistry}`}]:[]};}
async function report(account,withAI=false){account=getAddress(account);const s=await position(p,account);const risk=assess(s);return {version:'V0.0.2',position:s,risk,...(withAI?{explanation:await explain(s,risk)}:{})};}
const tools=[{name:'venus_position',description:'Read a Venus Core BSC Testnet position and deterministic risk assessment. Does not sign or send transactions.',inputSchema:{type:'object',properties:{account:{type:'string',pattern:'^0x[0-9a-fA-F]{40}$'}},required:['account'],additionalProperties:false}}];
async function body(req){let text='';for await(const c of req){text+=c;if(text.length>8192)throw new Error('BODY_TOO_LARGE');}return JSON.parse(text);}
function send(res,code,obj){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(json(obj));}
const server=http.createServer(async(req,res)=>{
 try{
  const u=new URL(req.url,'http://localhost');
  const allowedHosts=new Set(['localhost','127.0.0.1',new URL(base()).hostname]);
  if(!allowedHosts.has((req.headers.host||'').split(':')[0]))return send(res,403,{error:'HOST_DENIED'});
  const ip=req.socket.remoteAddress;const now=Date.now();let limit=limits.get(ip);if(!limit||now-limit.start>60000){limit={start:now,count:0};limits.set(ip,limit);}if(++limit.count>60)return send(res,429,{error:'RATE_LIMIT'});
  if(limits.size>10000)for(const [k,v] of limits)if(now-v.start>60000)limits.delete(k);
  if(req.method==='GET'&&u.pathname==='/healthz')return send(res,beat.ok&&now-beat.lastSuccess<120000?200:503,{name:'BNB Guardian',version:'V0.0.2',chainId:97,monitor:beat,execution:'user-confirmation-required',aiConfigured:!!(process.env.OPENAI_API_KEY&&process.env.OPENAI_MODEL),registered:!!process.env.AGENT_ID,publicBaseConfigured:!!process.env.PUBLIC_BASE_URL});
  if(req.method==='GET'&&['/agent-registration.json','/.well-known/agent-card.json'].includes(u.pathname))return send(res,200,registration());
  if(req.method==='GET'&&u.pathname==='/v1/position')return send(res,200,await report(u.searchParams.get('account')));
  if(req.method==='GET'&&u.pathname==='/v1/watch')return send(res,200,{monitor:beat,positions:[...cache.values()]});
  if(req.method==='POST'&&u.pathname==='/mcp'){
   const x=await body(req);let result;
   if(x.jsonrpc!=='2.0')return send(res,400,{error:'INVALID_RPC'});
   if(x.id===undefined){res.writeHead(202);return res.end();}
   if(x.method==='initialize')result={protocolVersion:'2025-06-18',capabilities:{tools:{}},serverInfo:{name:'bnb-guardian',version:'0.0.2'}};
   else if(x.method==='tools/list')result={tools};
   else if(x.method==='tools/call'&&x.params?.name==='venus_position')result={content:[{type:'text',text:json(await report(x.params.arguments?.account))}]};
   else return send(res,200,{jsonrpc:'2.0',id:x.id,error:{code:-32601,message:'Method not found'}});
   return send(res,200,{jsonrpc:'2.0',id:x.id,result});
  }
  if(req.method==='GET'&&u.pathname==='/'){res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8'});return res.end('BNB Guardian V0.0.2\nBSC Testnet 97 · Venus health-factor coverage\n/healthz\n/agent-registration.json\n/mcp\n/v1/position?account=0x…\nLocal review build: not listed, not registered, no private keys, no transactions sent.');}
  return send(res,404,{error:'NOT_FOUND'});
 }catch{return send(res,503,{error:'REQUEST_OR_CHAIN_UNAVAILABLE',transactionSent:false});}
});
server.requestTimeout=25000;server.headersTimeout=10000;
server.listen(Number(process.env.PORT||8797),process.env.HOST||'127.0.0.1',()=>console.log('BNB Guardian V0.0.2 local service started. No signer is configured.'));
function stop(){clearInterval(timer);server.close();p.destroy();}process.on('SIGTERM',stop);process.on('SIGINT',stop);
