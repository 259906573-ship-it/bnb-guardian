import test from 'node:test';import assert from 'node:assert/strict';
import {Interface} from 'ethers';import {prepareRegister} from '../src/prepare.js';import {registryAbi,network} from '../src/chain.js';
const wallet='0x9F81A9588c310b90A0636E8D2fb31523a57fbaDC';
const p={send:async()=> '0x61',getBlock:async()=>({number:1,hash:'0x'+'1'.repeat(64),timestamp:Math.floor(Date.now()/1000)})};
test('Registration requires real HTTPS and produces unsigned intent',async()=>{await assert.rejects(prepareRegister(p,wallet,'http://localhost:8797'));const x=await prepareRegister(p,wallet,'https://guardian.example.org');assert.equal(x.broadcast,false);assert.equal(x.requiresUserConfirmation,true);assert.equal(x.to,network.identityRegistry);assert.equal(new Interface(registryAbi).decodeFunctionData('register(string)',x.data)[0],'https://guardian.example.org/agent-registration.json');});
